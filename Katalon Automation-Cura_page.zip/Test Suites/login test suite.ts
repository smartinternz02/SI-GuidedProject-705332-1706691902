<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>login test suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>dcff868f-ad26-4500-b55a-365cf4eb1ba1</testSuiteGuid>
   <testCaseLink>
      <guid>3997b1e7-08f1-425f-9073-b0a8997532ec</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Buttons/TC_Cura_login_003</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>2cc8b2ef-7aab-4633-ad05-672f62e0e8e0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Buttons/TC_Cura_login_004</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>bc90557c-402e-48fd-93f0-fce41d184c1c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Data_Driven_testing/TC_Cura_login_002</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>f9d03a3e-f6ce-4067-8ae2-36139ca6afe2</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/invalid_cred</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>f9d03a3e-f6ce-4067-8ae2-36139ca6afe2</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>username</value>
         <variableId>f813b397-2731-4e84-84af-805c12a931e2</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>f9d03a3e-f6ce-4067-8ae2-36139ca6afe2</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>b7f9ab2d-5f3a-4f49-85a4-a82ff53729eb</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>558532db-6c25-4ff3-b507-1f8aaa80ffd4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Local_and_global_variables/Global_variables/TC_Cura_login_001</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
