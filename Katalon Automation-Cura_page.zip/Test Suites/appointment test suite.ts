<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>appointment test suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>43b106ca-a587-4939-837a-6e01fc76663e</testSuiteGuid>
   <testCaseLink>
      <guid>64ce6770-b949-4d67-a140-cb7b2544adae</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Buttons/TC_Cura_appointment_002</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>a9a23a99-e3ec-4abe-a0de-47b332636c33</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data_Driven_testing/TC_Cura_appointment_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>6e28d34a-94e9-436e-ba6a-04798ae58ac7</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/appointment_data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>6e28d34a-94e9-436e-ba6a-04798ae58ac7</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>facility</value>
         <variableId>22e8cd41-c490-4e5c-9339-7ad55ad4b9c4</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
